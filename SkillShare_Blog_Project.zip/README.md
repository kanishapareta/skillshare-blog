# SkillShare Blog Project

A full-stack blog platform using Next.js, MongoDB, and React-Quill.