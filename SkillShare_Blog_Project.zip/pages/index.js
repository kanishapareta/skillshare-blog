import Head from 'next/head';
export default function Home() { return (<div><Head><title>SkillShare</title></Head><h1>Welcome to SkillShare Blog</h1></div>); }