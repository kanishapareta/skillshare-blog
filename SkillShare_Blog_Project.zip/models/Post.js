const mongoose = require('mongoose');
const PostSchema = new mongoose.Schema({ title: String, slug: String, content: String });
module.exports = mongoose.models.Post || mongoose.model('Post', PostSchema);